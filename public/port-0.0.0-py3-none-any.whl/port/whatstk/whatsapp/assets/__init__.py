"""Static assets."""
