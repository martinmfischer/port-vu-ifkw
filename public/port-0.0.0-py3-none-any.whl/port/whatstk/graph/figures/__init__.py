"""Build Plotly compatible Figures."""
