"""Library generic utils."""
