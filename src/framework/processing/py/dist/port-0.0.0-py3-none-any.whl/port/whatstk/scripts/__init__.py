"""Library generic scripts."""
